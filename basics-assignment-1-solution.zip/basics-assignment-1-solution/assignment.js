const userInput = 20;
let result;

result = 18 + userInput;

result = result - 10;
result = result * 2;
result = result / 4;

alert(result);
alert(userInput);